<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <style>

        .back{
        
            background-image:url(stadium.jpg);
             background-size: cover;
              background-attachment: fixed;
        
        }
    

        .op{

           
            /* filter: alpha(opacity=50);
            background-image:url(maroon.png); */
            background-color: rgba(83, 0, 28, 0.8);
            background-size: cover;
            background-attachment: fixed;
            
        }
       
        </style>

</head>
<body>
   
    <header>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
           
            <a href="" class="navbar-brand">
                <img src="DU logo.png" alt="logo" style= "width: 70px;">
            </a>
             <div class="col-lg-3">
                <h3 class="text-white mr-5">DACCA UNITED</h3>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
               
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"><a class="nav-link active" href="home.html">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="team-card.html">Team</a></li>
                    <li class="nav-item"><a class="nav-link" href="News.html">News</a></li>
                    <li class="nav-item"><a class="nav-link" href="Matches.html">Matches</a></li>
                    <li class="nav-item"><a class="nav-link" href="Tickets.html">Ticket</a></li>
                    <li class="nav-item"><a class="nav-link" href="store.html">Store</a></li>
                    <li class="nav-item"><a class="nav-link" href="">Signup</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.html">Login</a></li>
                </ul>
              </div>
           
        </nav>
    </header>
    

    
    
    <div class="container-fluid back"> 
        <div class="row justify-content-center text-center pt-5 p-5 pb-4">
        

                        <div class="col-lg-4 pt-5">
                        <div class="card border-5 border-warning op"> 
                        <div class="card-body">
                        <h2 class="card-title text-white">Next Match</h2>
                        <h5 class="card-title pb-4 text-success">BPL</h5>
                        <h2 class="card-title text-warning">Dacca United</h2>
                        <h5 class="card-title text-white">Vs</h5>
                        <h2 class="card-title text-danger pb-2">Bashundhara Kings</h2>
                        <h4 class="card-title pt-2 text-white">Time: 26 January, 2021. 7:00 PM</h4>
                        <h4 class="card-title pb-3 text-white">North South Stadium</h4>
                        <a class="class-link" target="_blank" href="Tickets.html">Tickets</a>
                        </div>
                    </div>
    
                </div>
    
        </div>  

    </div>



        <!--Card-->
    <div class="container-fluid">
        <div class="tuts border">
               
        <div class="title text-center">
            <h3 class= "font-weight bolder pb-3 pt-3"> News</h3>
    </div> 
            <div class="row text-center">
    
                <div class="col-lg-3 ">
                        <div class="card bg-white">
                                <img class="card-img-top mx-auto" src="messi.jpg" alt="messi" style="width: 300px; height:300px;">
                                <div class="card-body">
                                    <h4 class="card-title">Messi Joining Dacca United</h4>
                                    <p class="card-text">After all the suspense and drama Lionel Messi is coming to Dacca United this season. Messi is excited to come to Dacca and show his charisma.</p>
                                    <a class="class-link stretched-link" target="_blank" href="News.html">Visit News</a>
                                </div>
                        </div>
                 </div>
                 <div class="col-lg-3">
                    <div class="card bg-white">
                            <img class="card-img-top mx-auto" src="jamal.jpg" alt="jamal" style="width: 300px; height:300px;" >
                            <div class="card-body">
                                <h4 class="card-title">Man of The match Jamal</h4>
                                <p class="card-text">Midfielder Jamal Bhuyan showed his real class in the last game with 2 assists and 1 goal in the Champions League. He is hopeful that Dacca will win this year.</p>
                                <a class="class-link stretched-link" target="_blank" href="News.html">Visit News</a>
                            </div>
                    </div>
             </div>
    
             <div class="col-lg-3">
                <div class="card bg-white">
                        <img class="card-img-top mx-auto"src="ron.jpg" alt="ron" style="width: 350px; height:300px;">
                        <div class="card-body">
                            <h4 class="card-title">Ronaldo Wants to Join Dacca</h4>
                            <p class="card-text">Transfer negotiation is going on about Cristiano and he gave a positive vibe about Dacca by saying he's interested.Perez, Ramos, Marcelo also excited about the reunion.</p>
                            <a class="class-link stretched-link" target="_blank" href="News.html">Visit News</a>
                        </div>
                </div>
         </div>
         <div class="col-lg-3">
            <div class="card bg-white">
                    <img class="card-img-top mx-auto" src="perez.jpg" alt="messi" style="width: 300px; height:290px;">
                    <div class="card-body">
                        <h4 class="card-title">Perez Is Happy With The Performance</h4>
                        <p class="card-text">Dacca United's Director of Football Florentino Perez is happy with the performance.He also said,"New surprises are coming in this transfer window"</p>
                        <a class="class-link stretched-link" target="_blank" href="News.html">Visit News</a>
                    </div>
            </div>
     </div>
            </div>
        </div>
    </div>
            
    <div class="container-fluid">
    <div class="row text-center justify-content-center pb-3 pt-3">

        <div class="col-lg-4 border-5">
                <div class="card bg-white border-5">
                        <div class="card-body">
                            <h4 class="card-title">Last Game Result</h4>
                            <h5 class="card-title">AFC Champions League</h5>
                            <h5 class="card-title">Dacca United 2:0 Ulsan Hyundai</h5>
                            <a class="class-link stretched-link" target="_blank" href="Matches.html">Match Results</a>
                        </div>
                </div>
                <div class="card bg-white border-5">
                        <div class="card-body">
                            <h2 class="card-title">League Position</h2>
                            <h1 class="card-title">1st</h1>
                        </div>
                </div>

                <div class="card bg-white border-5">
                    <div class="card-body">
                        <h1 class="card-title">Honors</h1>
                        <h5 class="card-title">5X Bangladesh Premier League</h5>
                        <h5 class="card-title">3X AFC Champions League</h5>
                        <h5 class="card-title">4X Bangladesh Super Cup</h5>
                        <h5 class="card-title">2X Federation Cup</h5>
                       
                    </div>
            </div>
            </div>        
         

         <div class="col-lg-4 border-5">
         <div class="card bg-white border-5">
            <h2 class="card-title">Top Scorer</h2>    
            <img class="card-img-top mx-auto" src="Lewa.png" alt="lewa" style="width: 300px; height:300px;" >
                <div class="card-body">
                    <h2 class="card-title">Robert Lewandowski</h2>
                    <h3 class="card-title">Matches: 22</h3>
                    <h3 class="card-title">Goals: 19</h3>
                    <a class="class-link stretched-link" target="_blank" href="team-card.html">Visit Players</a>
                </div>
        </div>
    </div>     
    <div class="col-lg-4 border-5">
        <div class="card bg-white border-5">
           <h2 class="card-title">Top Assist</h2>    
           <img class="card-img-top mx-auto" src="Bruno.jpg" alt="bruno" style="width: 300px; height:300px;" >
               <div class="card-body">
                   <h2 class="card-title">Bruno Fernandes</h2>
                   <h3 class="card-title">Matches: 22</h3>
                   <h3 class="card-title">Assists: 17</h3>
                   <a class="class-link stretched-link" target="_blank" href="team-card.html">Visit Players</a>
               </div>
       </div>
   </div>     


</div>     
</div>
    










    
    <div class="container-fluid bg-light">
        <h4 class="pt-5 font-weight bolder text-center">Our Sponsors</h4>
        <div class= "row">
            <div class="col-lg-2 pt-2 ">
                <div class="media">
                    <img src="Like.png" alt="logo" style="width: 210px; height:210px;">
                </div>
            </div>
            <div class="col-lg-2 ">
                <div class="media">
                    <img src="Fraud.png" alt="logo" style="width: 210px; height:150px;">
                </div>
            </div>
            <div class="col-lg-2 ">
                <div class="media p-2">
                    <img src="Diet.png" alt="logo" style="width: 210px; height:210px;">
                </div>
            </div>
            <div class="col-lg-2 ">
                <div class="media p-2">
                    <img src="Hotqueen.png" alt="logo" style="width: 210px; height:210px;">
                </div>
            </div>
            <div class="col-lg-2 ">
                <div class="media p-2">
                    <img src="adios.png" alt="logo" style="width: 210px; height:210px;">
                </div>
            </div>
            <div class="col-lg-2 ">
                <div class="media p-2">
                    <img src="oops.png" alt="logo" style="width: 210px; height:150px;">
                </div>
            </div>
        
        </div>

        <div class="mb-3 my-5"></div>







        <footer>
            <div class="my-2 border"></div>
         <div class="bg-dark">
            <div class= "row pt-3  m-2 text-white">
                <div class="col-lg-1 ">
    
                </div>
            <div class="col-lg-5 pl-3 pr-2">
                <div class="media p-2 ">
                    <img src="DU logo.png" alt="logo" style="width: 210px; height:150px;">
                </div>
                
                <h5 class="pl-3 font-weight bolder">North South Stadium</h5>
                <h6>Bashundhara, Dhaka-1229, Bangladesh</h6>
                <h6>Phone: +880191642x</h6>
                <a href="https://www.google.com/maps/dir/23.7504462,90.405772/%27%27/@23.7839757,90.377029,13z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3755c64c1968cc97:0x92043f043afdc8e3!2m2!1d90.4255053!2d23.8157775" class="btn btn-outline-light">Location</a><br><br>
                
    
            </div>
            <div class="col-lg-5 pt-4 ">
                <h3 class="pt-5 font-weight bolder text-center">About Us</h3>
                <p><h5 class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores temporibus deserunt, dolorum corrupti blanditiis numquam rerum, consequuntur autem sapiente illo aliquid debitis porro ipsa nobis inventore quo sequi quibusdam minus.</h5></p>  
                <p class="pt-4 pl-5 text-center"> Copyright © Premier Noobs - 2021 All Rights Reserved.  </p>
            </div>
            <div class="col-lg-1">
            </footer>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>


</body>
</html>